let button = document.getElementById("submit-btn");
let action = button.addEventListener("click", function (){
alert("Button clicked!")
});
console.log(action);